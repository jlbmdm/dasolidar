import os
import sys
import time
from datetime import datetime
import re
import smtplib

import win32com.client
import pythoncom
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def limpiar_nombre_archivo(nombre):
    # Reemplazar caracteres no permitidos con un guion bajo
    nombre_limpio = re.sub(r"[<>:'/\\|?*]", '_', nombre)
    # Eliminar caracteres no alfanuméricos (excepto guiones bajos y puntos)
    nombre_limpio = re.sub(r'[^a-zA-Z0-9_.-]', '_', nombre_limpio)
    nombre_limpio = nombre_limpio.strip()
    max_length = 255
    if len(nombre_limpio) > max_length:
        nombre_limpio = nombre_limpio[:max_length]
    return nombre_limpio

# ==============================================================================
def procesar_mensaje_dasolidar(mensaje):
    hoy_AAAAMMDD = datetime.fromtimestamp(time.time()).strftime('%Y%m%d')
    ahora_HHMMSS = datetime.fromtimestamp(time.time()).strftime('%H:%M:%S')
    ahora_H_M_SS = datetime.fromtimestamp(time.time()).strftime('%H%M%S')

    # https://learn.microsoft.com/en-us/dotnet/api/microsoft.office.interop.outlook.mailitem?view=outlook-pia&redirectedfrom=MSDN#properties_
    su_asunto = mensaje.Subject
    if su_asunto.startswith('dsld_'):
        dsld_tipo = su_asunto[5: -9]
        remitente332 = su_asunto[-8:]
    if su_asunto.startswith('dsld_sugerencia'):
        pass
    elif su_asunto.startswith('dsld_consulta'):
        pass
    elif su_asunto.startswith('dsld_bengi'):
        pass
    elif su_asunto.startswith('dsld_vega'):
        pass
    elif su_asunto.startswith('dsld_accion'):
        pass

    # print(f'mensaje_atributos_all = {dir(mensaje)}')
    # mensaje_atributos_all = [
    #     'Actions', 'AddBusinessCard', 'AlternateRecipientAllowed', 'Application', 'Attachments', 'AutoForwarded',
    #     'AutoResolvedWinner', 'BCC', 'BillingInformation', 'Body', 'BodyFormat', 'CC', 'CLSID', 'Categories', 
    #     'Class', 'ClearConversationIndex', 'ClearTaskFlag', 'Close', 'Companies', 'Conflicts', 'ConversationID',
    #     'ConversationIndex', 'ConversationTopic', 'Copy', 'CreationTime', 'DeferredDeliveryTime', 'Delete',
    #     'DeleteAfterSubmit', 'Display', 'DownloadState', 'EnableSharedAttachments', 'EntryID', 'ExpiryTime',
    #     'FlagDueBy', 'FlagIcon', 'FlagRequest', 'FlagStatus', 'FormDescription', 'Forward', 'GetConversation',
    #     'GetInspector', 'HTMLBody', 'HasCoverSheet', 'Importance', 'InternetCodepage', 'IsConflict', 'IsIPFax',
    #     'IsMarkedAsTask', 'ItemProperties', 'LastModificationTime', 'Links', 'MAPIOBJECT', 'MarkAsTask',
    #     'MarkForDownload', 'MessageClass', 'Mileage', 'Move', 'NoAging', 'OriginatorDeliveryReportRequested',
    #     'OutlookInternalVersion', 'OutlookVersion', 'Parent', 'Permission', 'PermissionService', 'PermissionTemplateGuid',
    #     'PrintOut', 'PropertyAccessor', 'RTFBody', 'ReadReceiptRequested', 'ReceivedByEntryID', 'ReceivedByName',
    #     'ReceivedOnBehalfOfEntryID', 'ReceivedOnBehalfOfName', 'ReceivedTime', 'RecipientReassignmentProhibited',
    #     'Recipients', 'ReminderOverrideDefault', 'ReminderPlaySound', 'ReminderSet', 'ReminderSoundFile', 'ReminderTime',
    #     'RemoteStatus', 'Reply', 'ReplyAll', 'ReplyRecipientNames', 'ReplyRecipients', 'RetentionExpirationDate',
    #     'RetentionPolicyName', 'Save', 'SaveAs', 'SaveSentMessageFolder', 'Saved', 'Send', 'SendUsingAccount',
    #     'Sender', 'SenderEmailAddress', 'SenderEmailType', 'SenderName', 'Sensitivity', 'Sent', 'SentOn',
    #     'SentOnBehalfOfName', 'Session', 'ShowCategoriesDialog', 'Size', 'Subject', 'Submitted', 'TaskCompletedDate', 
    #     'TaskDueDate', 'TaskStartDate', 'TaskSubject', 'To', 'ToDoTaskOrdinal', 'UnRead', 'UserProperties', 'VotingOptions', 'VotingResponse',
    # ]
    # print()
    # print('>>>>>>>>>>>>>>')
    # for mi_atributo in mensaje_atributos_all:
    #     try:
    #         if hasattr(mensaje, mi_atributo):
    #             propiedad = getattr(mensaje, mi_atributo, '{mi_atributo} no disponible')
    #             # contact_name = contact.FullName
    #         else:
    #             propiedad = 'Atributo no disponible'
    #     except Exception as e:
    #         print(f'Error al procesar el contacto: {e}')
    #     try:
    #         print(f'\t{mi_atributo}:-> ({type(propiedad)}): {propiedad}')
    #     except:
    #         print(f'\t{mi_atributo};-> {type(propiedad)}')
    # print('<<<<<<<<<<<<<<<')
    # print()

    # Guardar el texto del mensaje en un archivo
    if su_asunto.startswith('dsld_'):
        msg_path = os.path.abspath(os.path.join('mails', dsld_tipo))
        msg_text = f'{dsld_tipo}\t{remitente332}\t'
        msg_head = f'tipo\tcod332\tSenderEmailAddress\tstrftime\tPrimarySmtpAddress\tFirstName\tLastName\tJobTitle\tDepartment\tSubject\tBodyLine1'
    else:
        msg_path = os.path.abspath(os.path.join('mails', 'otros'))
        msg_text = f''
        msg_head = f'SenderEmailAddress\tstrftime\tPrimarySmtpAddress\tFirstName\tLastName\tJobTitle\tDepartment\tSubject\tBodyLine1'
    if not os.path.exists(msg_path):
        os.makedirs(msg_path)
    msg_filename = os.path.join(msg_path, 'input_data.csv')

    with open(msg_filename, 'a', encoding='utf-8') as msg_obj:
        msg_obj.write(f'{msg_head}\n')
        try:
            # msg_text += f'{mensaje.SenderEmailAddress}\t'
            # msg_text += f'{mensaje.SenderName}\t'
            # msg_text += f'{mensaje.Sender.Address}\t'
            msg_text += f'{mensaje.Sender.Name}\t'
            # msg_text += f'{mensaje.ReceivedTime}\t'
            # msg_text += f'{mensaje.ReceivedTime.date()}\t'
            # msg_text += f'{mensaje.ReceivedTime.time()}\t'
            msg_text += f'{mensaje.ReceivedTime.strftime("%Y-%m-%d %H:%M:%S")}\t'
            # msg_obj.write(f'Hora: {mensaje.ReceivedTime}')
            # print(f'RecievedTime ({type(mensaje.ReceivedTime)}): {mensaje.ReceivedTime}')
            # print(f'Date ({type(mensaje.ReceivedTime.date())}): {mensaje.ReceivedTime.date()}')
            # print(f'Time ({type(mensaje.ReceivedTime.time())}): {mensaje.ReceivedTime.time()}')
            # print(f'strftime ({type(mensaje.ReceivedTime.strftime())}): {mensaje.ReceivedTime.strftime()}')
            # print(f'dir: {dir(mensaje.ReceivedTime)}-> ')

            if hasattr(mensaje, 'Sender') and mensaje.Sender:
                sender = mensaje.Sender
                # print(f'sender_atributos_all = {dir(sender)}')
                # sender_atributos_all = [
                #     'Address', 'AddressEntryUserType', 'Application', 'CLSID', 'Class', 'Delete', 'Details', 'DisplayType',
                #     'GetContact', 'GetExchangeDistributionList', 'GetExchangeUser', 'GetFreeBusy', 'ID', 'MAPIOBJECT',
                #     'Manager', 'Members', 'Name', 'Parent', 'PropertyAccessor', 'Session', 'Type', 'Update', 'UpdateFreeBusy',
                # ]
                # print()
                # print('>>>>>>>>>>>>>>')
                # for mi_atributo in sender_atributos_all:
                #     try:
                #         if hasattr(sender, mi_atributo):
                #             propiedad = getattr(sender, mi_atributo, '{mi_atributo} no disponible')
                #             # contact_name = contact.FullName
                #         else:
                #             propiedad = 'Atributo no disponible'
                #     except Exception as e:
                #         print(f'Error al procesar el contacto: {e}')
                #     try:
                #         print(f'\t{mi_atributo}:-> ({type(propiedad)}): {propiedad}')
                #     except:
                #         print(f'\t{mi_atributo};-> {type(propiedad)}')
                # print('<<<<<<<<<<<<<<<')
                # print()

                # Obtener información básica
                # sender_name = sender.Name
                # print(f'sender_name:         {sender_name}')
                # sender_email = sender.Address
                # print(f'sender_email:        {sender_email}')

                # # Esto siempre es None
                # contact_user = sender.GetContact()
                # if contact_user:
                #     print(f'\ncontact_user_atributos_all = {dir(contact_user)}')

                # Obtener información de Exchange
                exchange_user = sender.GetExchangeUser()
                if exchange_user:
                    # print(f'\nexchange_user_atributos_all = {dir(exchange_user)}')
                    # exchange_user_atributos_all = ['CLSID', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattr__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__lt__', '__maybe__call__', '__maybe__int__', '__maybe__iter__', 
                    # '__maybe__len__', '__maybe__nonzero__', '__maybe__str__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', '_dispobj_', 'coclass_interfaces', 'coclass_sources', 'default_interface']
                    # print()
                    # print('>>>>>>>>>>>>>>')
                    # for mi_atributo in exchange_user_atributos_all:
                    #     try:
                    #         if hasattr(exchange_user, mi_atributo):
                    #             propiedad = getattr(exchange_user, mi_atributo, '{mi_atributo} no disponible')
                    #             # contact_name = contact.FullName
                    #         else:
                    #             propiedad = 'Atributo no disponible'
                    #     except Exception as e:
                    #         print(f'Error al procesar el contacto: {e}')
                    #     try:
                    #         print(f'\t{mi_atributo}:-> ({type(propiedad)}): {propiedad}')
                    #     except:
                    #         print(f'\t{mi_atributo};-> {type(propiedad)}')
                    # print('<<<<<<<<<<<<<<<')
                    # print()

                    # primary_smtp = exchange_user.PrimarySmtpAddress
                    msg_text += f'{exchange_user.PrimarySmtpAddress}\t'
                    # name = exchange_user.Name
                    # print(f'Nombre completo: {name}')
                    # firstName = exchange_user.FirstName
                    msg_text += f'{exchange_user.FirstName}\t'
                    # lastName = exchange_user.LastName
                    msg_text += f'{exchange_user.LastName}\t'
                    # display_name = exchange_user.DisplayName
                    # print(f'Nombre para mostrar: {display_name}')
                    # job_title = exchange_user.JobTitle
                    msg_text += f'{exchange_user.JobTitle}\t'
                    # department = exchange_user.Department
                    msg_text += f'{exchange_user.Department}\t'
                    # office = exchange_user.Office
                    # print(f'Oficina: {office}')
                else:
                    msg_text += f'----\t----\t----\t----\t----\t'
                    print('No se pudo obtener información de Exchange.')
        except Exception as e:
            print(f'Error al obtener información del remitente: {e}')

        # print(f'Asunto: {mensaje.Subject}')
        msg_text += f'{mensaje.Subject}\t'
        body_text = mensaje.Body
        # print(f'Texto del mensaje: {body_text}')
        mis_lineas = body_text.splitlines()
        for mi_linea in mis_lineas:
            if mi_linea.startswith('COD332'):
                msg_text += f'{mi_linea}\t'
            elif mi_linea.startswith('rodal'):
                msg_text += f'{mi_linea}\t'
            elif mi_linea.startswith('parcela'):
                msg_text += f'{mi_linea}\t'
            elif mi_linea.startswith('obs'):
                msg_text += f'{mi_linea}\t'
        msg_obj.write(f'{msg_text}\n')
        print(msg_text)
        if len(mis_lineas) > 1:
            print(f'\tMensaje con {len(mis_lineas)} lineas')
        print('=' * 40)


    # Guardar los archivos adjuntos en el msg_path correspondiente
    if su_asunto.startswith('dsld_'):
        msg_path = os.path.abspath(os.path.join('mails', dsld_tipo, remitente332, f'{hoy_AAAAMMDD}_{ahora_H_M_SS}'))
    else:
        msg_path = os.path.abspath(os.path.join('mails', 'otros', f'{limpiar_nombre_archivo(mensaje.Subject)}_{hoy_AAAAMMDD}_{ahora_H_M_SS}'))
    if not os.path.exists(msg_path):
        os.makedirs(msg_path)
    for adjunto in mensaje.Attachments:
        adjunto_filename = limpiar_nombre_archivo(adjunto.FileName)
        adjunto_filepath = os.path.join(msg_path, adjunto_filename)
        print(f'Se va a guardar: {adjunto.FileName} -> {adjunto_filepath}')
        adjunto.SaveAsFile(adjunto_filepath)
        print(f'Archivo adjunto guardado: {adjunto_filepath}')




# https://stackoverflow.com/questions/22813814/clearly-documented-reading-of-emails-functionality-with-python-win32com-outlook

class OutlookListener:
    def __init__(self):
        self.outlook = win32com.client.DispatchWithEvents('Outlook.Application', OutlookEvents)

    def on_new_mail(self, item):
        # Este método se llamará cuando llegue un nuevo correo
        # if item.Subject and item.Subject.startswith('dsld_)'):
        if item.Subject:
            procesar_mensaje_dasolidar(item)
            # print(f'Atributos de mensaje ({type(item)}): {dir(item)}')

class OutlookEvents:
    def OnNewMailEx(self, receivedItemsIDs):
        # Este evento se activa cuando se recibe un nuevo correo
        outlook = win32com.client.Dispatch('Outlook.Application')
        for item_id in receivedItemsIDs.split(','):
            item = outlook.Session.GetItemFromID(item_id)
            if item:
                # Llama al método de la clase OutlookListener
                listener.on_new_mail(item)


escuchar_outlook = True
if escuchar_outlook:
    listener = OutlookListener()
    print('->Escuchando nuevos correos en Outlook...')
    time_ini_abs = time.time()
    time_ini_lap = time.time()
    ciclo = 0
    num_mails = 0
    while True:
        pythoncom.PumpWaitingMessages()
        time_fin_lap = time.time()
        if ciclo == 0 or time_fin_lap - time_ini_lap >= 60:
            print(f'Tiempo ejecución: {round((time.time() - time_ini_abs) / 60): 0.2f} min -> Ciclos: {(ciclo / 1000):0.1f} miles -> Mails: {num_mails}')  # Mostrar el texto
            time_ini_lap = time_fin_lap  #
        if time.time() - time_ini_abs > 60 * 60 * 24:
            break
        time.sleep(1)
        ciclo += 1
    print('Fin de escuchando nuevos correos en Outlook...')



sys.exit()


# ==============================================================================
class OutlookReader:
    def __init__(self):
        # self.outlook = win32com.client.DispatchWithEvents('Outlook.Application', OutlookEvents)
        self.outlook = win32com.client.Dispatch('Outlook.Application').GetNamespace('MAPI')

    def on_new_mail(self, item):
        # Este método se llamará cuando llegue un nuevo correo
        # if item.Subject and item.Subject.startswith('dsld_)'):
        if item.Subject:
            procesar_mensaje_dasolidar(item)

class OutlookEvents:
    def OnNewMailEx(self, receivedItemsIDs):
        # Este evento se activa cuando se recibe un nuevo correo
        outlook = win32com.client.Dispatch('Outlook.Application')
        for item_id in receivedItemsIDs.split(','):
            item = outlook.Session.GetItemFromID(item_id)
            if item:
                # Llama al método de la clase OutlookReader
                listener.on_new_mail(item)


if False:
    # Bandeja de entrada
    inbox_atributos_todos = ['Actions', 'AddBusinessCard', 'AlternateRecipientAllowed', 'Application',
    'Attachments', 'AutoForwarded', 'AutoResolvedWinner',
    'BCC', 'BillingInformation',
    'Body', 'BodyFormat', 'CC', 'CLSID', 'Categories', 'Class', 'ClearConversationIndex', 'ClearTaskFlag',
    'Close', 'Companies', 'Conflicts', 'ConversationID', 'ConversationIndex', 'ConversationTopic', 'Copy',
    'CreationTime', 'DeferredDeliveryTime', 'Delete', 'DeleteAfterSubmit', 'Display', 'DownloadState', 'EnableSharedAttachments', 'EntryID',
    'ExpiryTime', 'FlagDueBy', 'FlagIcon', 'FlagRequest', 'FlagStatus', 'FormDescription', 'Forward', 'GetConversation', 'GetInspector',
    'HTMLBody', 'HasCoverSheet', 'Importance', 'InternetCodepage', 'IsConflict', 'IsIPFax', 'IsMarkedAsTask',
    'ItemProperties', 'LastModificationTime', 'Links', 'MAPIOBJECT', 'MarkAsTask', 'MarkForDownload', 'MessageClass', 'Mileage', 'Move', 'NoAging',
    'OriginatorDeliveryReportRequested', 'OutlookInternalVersion', 'OutlookVersion', 'Parent', 'Permission', 'PermissionService',
    'PermissionTemplateGuid', 'PrintOut', 'PropertyAccessor', 'RTFBody', 'ReadReceiptRequested',
    'ReceivedByEntryID', 'ReceivedByName', 'ReceivedOnBehalfOfEntryID', 'ReceivedOnBehalfOfName',
    'ReceivedTime', 'RecipientReassignmentProhibited',
    'Recipients', 'ReminderOverrideDefault', 'ReminderPlaySound', 'ReminderSet', 'ReminderSoundFile', 'ReminderTime', 'RemoteStatus',
    'Reply', 'ReplyAll', 'ReplyRecipientNames', 'ReplyRecipients', 'RetentionExpirationDate', 'RetentionPolicyName',
    'Save', 'SaveAs', 'SaveSentMessageFolder', 'Saved', 'Send', 'SendUsingAccount',
    'Sender', 'SenderEmailAddress', 'SenderEmailType', 'SenderName',
    'Sensitivity', 'Sent', 'SentOn', 'SentOnBehalfOfName', 'Session', 'ShowCategoriesDialog', 'Size',
    'Subject', 'Submitted', 'TaskCompletedDate', 'TaskDueDate', 'TaskStartDate', 'TaskSubject',
    'To', 'ToDoTaskOrdinal', 'UnRead', 'UserProperties', 'VotingOptions', 'VotingResponse',]

    # contacto
    contacto_atributos_todos = ['Account', 'Actions', 'AddBusinessCardLogoPicture', 'AddPicture', 'Anniversary', 'Application', 'AssistantName', 'AssistantTelephoneNumber', 'Attachments', 
    'AutoResolvedWinner', 'BillingInformation', 'Birthday',
    'Body', 'Business2TelephoneNumber', 'BusinessAddress', 'BusinessAddressCity', 'BusinessAddressCountry',
    'BusinessAddressPostOfficeBox', 'BusinessAddressPostalCode', 'BusinessAddressState', 'BusinessAddressStreet',
    'BusinessCardLayoutXml', 'BusinessCardType', 'BusinessFaxNumber', 'BusinessHomePage', 'BusinessTelephoneNumber',
    'CLSID', 'CallbackTelephoneNumber', 'CarTelephoneNumber', 'Categories', 'Children', 'Class', 'ClearTaskFlag', 'Close',
    'Companies', 'CompanyAndFullName', 'CompanyLastFirstNoSpace', 'CompanyLastFirstSpaceOnly', 'CompanyMainTelephoneNumber', 'CompanyName',
    'ComputerNetworkName', 'Conflicts', 'ConversationID', 'ConversationIndex', 'ConversationTopic', 'Copy',
    'CreationTime', 'CustomerID', 'Delete', 'Department', 'Display', 'DownloadState',
    'Email1Address', 'Email1AddressType', 'Email1DisplayName', 'Email1EntryID', 'Email2Address', 'Email2AddressType',
    'Email2DisplayName', 'Email2EntryID', 'Email3Address', 'Email3AddressType', 'Email3DisplayName', 'Email3EntryID',
    'EntryID', 'FTPSite', 'FileAs', 'FirstName', 'FormDescription', 'ForwardAsBusinessCard', 'ForwardAsVcard',
    'FullName', 'FullNameAndCompany', 'Gender', 'GetConversation', 'GetInspector', 'GovernmentIDNumber',
    'HasPicture', 'Hobby', 'Home2TelephoneNumber', 'HomeAddress', 'HomeAddressCity', 'HomeAddressCountry',
    'HomeAddressPostOfficeBox', 'HomeAddressPostalCode', 'HomeAddressState', 'HomeAddressStreet', 'HomeFaxNumber',
    'HomeTelephoneNumber', 'IMAddress', 'ISDNNumber', 'Importance', 'Initials', 'InternetFreeBusyAddress',
    'IsConflict', 'IsMarkedAsTask', 'ItemProperties', 'JobTitle', 'Journal', 'Language',
    'LastFirstAndSuffix', 'LastFirstNoSpace', 'LastFirstNoSpaceAndSuffix', 'LastFirstNoSpaceCompany',
    'LastFirstSpaceOnly', 'LastFirstSpaceOnlyCompany', 'LastModificationTime', 'LastName', 'LastNameAndFirstName',
    'Links', 'MAPIOBJECT',
    'MailingAddress', 'MailingAddressCity', 'MailingAddressCountry', 'MailingAddressPostOfficeBox', 'MailingAddressPostalCode', 'MailingAddressState', 'MailingAddressStreet',
    'ManagerName', 'MarkAsTask', 'MarkForDownload', 'MessageClass', 'MiddleName', 'Mileage',
    'MobileTelephoneNumber', 'Move', 'NetMeetingAlias', 'NetMeetingServer',
    'NickName', 'NoAging', 'OfficeLocation', 'OrganizationalIDNumber', 'OtherAddress', 'OtherAddressCity', 'OtherAddressCountry', 'OtherAddressPostOfficeBox',
    'OtherAddressPostalCode', 'OtherAddressState', 'OtherAddressStreet', 'OtherFaxNumber', 'OtherTelephoneNumber', 'OutlookInternalVersion', 'OutlookVersion',
    'PagerNumber', 'Parent', 'PersonalHomePage', 'PrimaryTelephoneNumber', 'PrintOut',
    'Profession', 'PropertyAccessor', 'RTFBody', 'RadioTelephoneNumber', 'ReferredBy',
    'ReminderOverrideDefault', 'ReminderPlaySound', 'ReminderSet', 'ReminderSoundFile', 'ReminderTime', 'RemovePicture', 'ResetBusinessCard',
    'Save', 'SaveAs', 'SaveBusinessCardImage', 'Saved', 'SelectedMailingAddress', 'Sensitivity', 'Session',
    'ShowBusinessCardEditor', 'ShowCategoriesDialog', 'ShowCheckAddressDialog', 'ShowCheckFullNameDialog', 'ShowCheckPhoneDialog',
    'Size', 'Spouse',
    'Subject', 'Suffix', 'TTYTDDTelephoneNumber', 'TaskCompletedDate', 'TaskDueDate', 'TaskStartDate', 'TaskSubject', 'TelexNumber',
    'Title', 'ToDoTaskOrdinal', 'UnRead', 'User1', 'User2', 'User3', 'User4', 'UserCertificate', 'UserProperties',
    'WebPage', 'YomiCompanyName', 'YomiFirstName', 'YomiLastName',]


    outlook = win32com.client.Dispatch('Outlook.Application').GetNamespace('MAPI')
    # print(f'outlook ({type(outlook)}): {outlook}')
    # print(f'Dir: {dir(outlook)}')
    # outlook_obj = OutlookReader
    for i in range(50):
        try:
            box = outlook.GetDefaultFolder(i)
        except:
            continue
            pass
        if True:
            name = box.Name
            print(f'\n{i}-> {name}')
            if name == 'Bandeja de entrada':
                contacts_folder = outlook.GetDefaultFolder(i)
                for num_contact, contact in enumerate(contacts_folder.Items):
                    # if num_contact == 0:
                    #     print(f'\nMetodos de {type(contact)}:\n{dir(contact)}')
                    if num_contact > 5:
                        break
                    atributos = [
                        # 'Sender', 'SenderEmailType',
                        'SenderName', 'SenderEmailAddress', 'ReceivedTime', 'Subject'
                    ]
                    print()
                    for mi_atributo in atributos:
                        try:
                            if hasattr(contact, mi_atributo):
                                propiedad = getattr(contact, mi_atributo, '{mi_atributo} no disponible')
                                # contact_name = contact.FullName
                            else:
                                propiedad = 'Atributo no disponible'
                        except Exception as e:
                            print(f'Error al procesar el contacto: {e}')
                        print(f'\t{mi_atributo}; {propiedad}')


            atributos_selec1 = [
                # 'Account', 'Body', 'Email1AddressType', 'Email1EntryID', 'Email2AddressType', 'Email2EntryID', 
                'Birthday','CreationTime',
                'Email1Address', 'Email1DisplayName',
                'Email2Address', 'Email2DisplayName', 
                'FirstName', 'MiddleName', 'LastName', 'LastNameAndFirstName', 'FullName', 
                'HasPicture', 
                'Home2TelephoneNumber', 'HomeAddress', 
                'HomeAddressStreet', 
                'MailingAddress', 'Profession', 
                'Subject', 'Suffix', ]
            atributos_selec2 = [
                'IMAddress', 'Email1Address',
                'Email1DisplayName',
                'FileAs', 'FirstName', 'MiddleName', 'LastName', 'FullName', 'LastNameAndFirstName',
                'LastModificationTime', 'CreationTime', 'JobTitle', 'Department',
                # 'BusinessAddress',
                'BusinessAddressCity', 'BusinessAddressPostalCode',
                'BusinessAddressState',
                # 'BusinessAddressStreet',
                'BusinessTelephoneNumber',
                'OfficeLocation',
                'Subject',
            ]

            # if name == 'Contactos' or name == 'Contactos de Skype Empresarial':
            if name == 'Contactos':
                contactos_filename = f'{name}.csv'
                contactos_obj = open(contactos_filename, mode='w')  #  'a+'
                # print(f'\nMetodos de {name}:\n{dir(box)}')
                # ['AddToFavorites', 'AddToPFFavorites', 'AddressBookName', 'Application', 'CLSID', 'Class', 'CopyTo', 'CurrentView',
                #  'CustomViewsOnly', 'DefaultItemType', 'DefaultMessageClass', 'Delete', 'Description', 'Display', 'EntryID',
                #  'FolderPath', 'Folders', 'FullFolderPath', 'GetCalendarExporter', 'GetCustomIcon', 'GetExplorer', 'GetOwner',
                #  'GetStorage', 'GetTable', 'InAppFolderSyncObject', 'IsSharePointFolder', 'Items', 'MAPIOBJECT', 'MoveTo',
                #  'Name', 'Parent', 'PropertyAccessor', 'Session', 'SetCustomIcon', 'ShowAsOutlookAB', 'ShowItemCount',
                #  'Store', 'StoreID', 'UnReadItemCount', 'UserDefinedProperties', 'UserPermissions', 'Views',
                #  'WebViewAllowNavigation', 'WebViewOn', 'WebViewURL', 'coclass_clsid']
                contacts_folder = outlook.GetDefaultFolder(i)
                print()
                mi_cabecera = ''
                for mi_atributo in atributos_selec2:
                    mi_cabecera += f'\t{mi_atributo}'
                # mi_cabecera += '\n'
                print(mi_cabecera)
                contactos_obj.write(f'{mi_cabecera}\n')

                total_contacts = len(contacts_folder.Items)  # Contar el total de contactos
                print(f'\nTotal de contactos en la carpeta: {total_contacts}')

                for num_contact, contact in enumerate(contacts_folder.Items):
                    # if num_contact == 0:
                    #     print(f'\nMetodos de {type(contact)}:\n{dir(contact)}')
                    if num_contact > 20000:
                        break
                    metodos = [ 'Display', ]
                    print()
                    print(f'+++++++>')
                    if contact.FirstName == 'Cepi' and False:
                        print()
                        print('>>>>>>>>>>>>>>')
                        for mi_atributo in atributos_todos:
                            try:
                                if hasattr(contact, mi_atributo):
                                    propiedad = getattr(contact, mi_atributo, '{mi_atributo} no disponible')
                                    # contact_name = contact.FullName
                                else:
                                    propiedad = 'Atributo no disponible'
                            except Exception as e:
                                print(f'Error al procesar el contacto: {e}')
                            try:
                                print(f'\t{mi_atributo} ({type(propiedad)}): {propiedad}')
                            except:
                                print(f'\t{mi_atributo} /// {type(propiedad)}')
                        print('<<<<<<<<<<<<<<<')
                        print()

                    mi_registro = f'{num_contact}'
                    for mi_atributo in atributos_selec2:
                        try:
                            if hasattr(contact, mi_atributo):
                                propiedad = getattr(contact, mi_atributo, '{mi_atributo} no disponible')
                                # contact_name = contact.FullName
                            else:
                                propiedad = 'Atributo no disponible'
                        except Exception as e:
                            print(f'Error al procesar el contacto: {e}')
                            continue
                        mi_registro += f'\t{propiedad}'
                        if False:
                            if mi_atributo == 'Email1Address':
                                # propiedad = '/o=JCYLEXORG/ou=Exchange Administrative Group (FYDIBOHF23SPDLT)/cn=Recipients/cn=RodMarLo'
                                if '/cn=' in str(propiedad):
                                    if propiedad.find('/cn=') + 12 == len(propiedad):
                                        user332 = propiedad[propiedad.find('/cn=')+4: propiedad.find('/cn=')+12]
                                        # mi_atributo = 'user332'
                                    elif propiedad[propiedad.find('/cn=') + 13] == '/':
                                        user332 = propiedad[propiedad.find('/cn=')+4: propiedad.find('/cn=')+12]
                                        # mi_atributo = 'user332'
                                    elif propiedad[-12:-8] == '/cn=':
                                        user332 = propiedad[propiedad.find('/cn=')+4:][-8:]
                                        # mi_atributo = 'user332'
                                    else:
                                        user332 = propiedad
                                else:
                                    user332 = propiedad
                                print(f'\tuser332: {user332}')
                            print(f'\t-> {mi_atributo} ({type(mi_atributo)}): {propiedad}')

                    # mi_registro += f'\n'
                    print(mi_registro)
                    contactos_obj.write(f'{mi_registro}\n')




            # if name == 'Contactos de Skype Empresarial':
            #     contactos_filename = f'{name}.csv'
            #     contactos_obj = open(contactos_filename, mode='w')  #  'a+'
            #     contacts_folder = outlook.GetDefaultFolder(i)
            #     mi_cabecera = ''
            #     for mi_atributo in atributos_selec2:
            #         mi_cabecera += f'\t{mi_atributo}'
            #     # mi_cabecera += '\n'
            #     print(mi_cabecera)
            #     contactos_obj.write(f'{mi_cabecera}\n')

            #     for num_contact, contact in enumerate(contacts_folder.Items):
            #         # if num_contact == 0:
            #         #     print(f'\nMetodos de {type(contact)}:\n{dir(contact)}')
            #         if num_contact > 100:
            #             break
            #         mi_registro = ''
            #         for mi_atributo in atributos_selec2:
            #             try:
            #                 if hasattr(contact, mi_atributo):
            #                     propiedad = getattr(contact, mi_atributo, '{mi_atributo} no disponible')
            #                     # contact_name = contact.FullName
            #                 else:
            #                     propiedad = 'Atributo no disponible'
            #             except Exception as e:
            #                 print(f'Error al procesar el contacto: {e}')
            #                 continue
            #             mi_registro += f'\t{propiedad}'
            #         print(mi_registro)
            #         contactos_obj.write(f'{mi_registro}\n')



                # contacts_folder = outlook.GetDefaultFolder(i)
                # for num_contact, contact in enumerate(contacts_folder.Items):
                #     if num_contact == 0:
                #         print(f'\nMetodos de {type(contact)}:\n{dir(contact)}')
                #     if num_contact > 10:
                #         break
                #     try:
                #         if hasattr(contact, 'FullName'):
                #             contact_name = contact.FullName
                #         else:
                #             contact_name = 'Nombre no disponible'
                #         if hasattr(contact, 'Email1Address'):
                #             email_address = contact.Email1Address
                #         else:
                #             email_address = 'Correo no disponible'
                #         if hasattr(contact, 'PrimaryTelephoneNumber'):
                #             phone_number = contact.PrimaryTelephoneNumber
                #         else:
                #             phone_number = 'Teléfono no disponible'

                #         # Imprimir las propiedades del contacto
                #         print(f'Nombre: {contact_name}')
                #         print(f'Correo electrónico: {email_address}')
                #         print(f'Número de teléfono: {phone_number}')
                #         print('-' * 40)  # Separador entre contactos
                #     except Exception as e:
                #         print(f'Error al procesar el contacto: {e}')
        # except Exception as e:
        #     print(f'Error aqui: {e}')

    # print(f'\nMetodos del box:\n{dir(box)}')
